from extra_packages.mtp_access_kio_gvfs.mtp_access_kio_gvfs import MTPClient

client = MTPClient()
devices = client.list_devices()
print("devices:", devices)

for device in devices:
    name = client.get_display_name(device)
    print(f"device={repr(device)} -> display_name={repr(name)}")